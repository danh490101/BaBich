/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'tt', {
	fontSize: {
		label: 'Зурлык',
		voiceLabel: 'Шрифт зурлыклары',
		panelTitle: 'Шрифт зурлыклары'
	},
	label: 'Шрифт',
	panelTitle: 'Шрифт исеме',
	voiceLabel: 'Шрифт'
} );
