/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'zh', {
	fontSize: {
		label: '大小',
		voiceLabel: '字型大小',
		panelTitle: '字型大小'
	},
	label: '字型',
	panelTitle: '字型名稱',
	voiceLabel: '字型'
} );
