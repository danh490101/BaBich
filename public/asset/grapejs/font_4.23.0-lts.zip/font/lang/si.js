/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'si', {
	fontSize: {
		label: 'විශාලත්වය',
		voiceLabel: 'අක්ෂර විශාලත්වය',
		panelTitle: 'අක්ෂර විශාලත්වය'
	},
	label: 'අක්ෂරය',
	panelTitle: 'අක්ෂර නාමය',
	voiceLabel: 'අක්ෂර'
} );
