/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'font', 'lv', {
	fontSize: {
		label: 'Lielums',
		voiceLabel: 'Fonta lielums',
		panelTitle: 'Fonta lielums'
	},
	label: 'Fonts',
	panelTitle: 'Fonta nosaukums',
	voiceLabel: 'Fonts'
} );
