﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'pl', {
	btn_about: 'Informacje o SCAYT',
	btn_dictionaries: 'Słowniki',
	btn_disable: 'Wyłącz SCAYT',
	btn_enable: 'Włącz SCAYT',
	btn_langs:'Języki',
	btn_options: 'Opcje',
	text_title:  'Sprawdź pisownię podczas pisania (SCAYT)'
});
