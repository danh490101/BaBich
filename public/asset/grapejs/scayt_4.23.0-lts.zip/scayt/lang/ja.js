﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ja', {
	btn_about: 'SCAYTﾊﾞｰｼﾞｮﾝ',
	btn_dictionaries: '辞書',
	btn_disable: 'SCAYT無効',
	btn_enable: 'SCAYT有効',
	btn_langs:'言語',
	btn_options: 'オプション',
	text_title:  'スペルチェック設定(SCAYT)'
});
