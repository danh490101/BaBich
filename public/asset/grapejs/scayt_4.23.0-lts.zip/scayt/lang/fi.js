﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'fi', {
	btn_about: 'Tietoja oikoluvusta kirjoitetaessa',
	btn_dictionaries: 'Sanakirjat',
	btn_disable: 'Poista käytöstä oikoluku kirjoitetaessa',
	btn_enable: 'Ota käyttöön oikoluku kirjoitettaessa',
	btn_langs:'Kielet',
	btn_options: 'Asetukset',
	text_title: 'Oikolue kirjoitettaessa'
});